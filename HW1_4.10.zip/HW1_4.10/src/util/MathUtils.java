package util;

import java.util.Arrays;

public class MathUtils {
    private MathUtils() {
    }

    public static double addAll(double... v) {
        /*double sum = 0;
        for (double oneFromV : v) {
            sum += oneFromV;
        }*/
        //Юрий,пока ломал голову над тем как правильно записать тело метода,
        // написал "double result = v." и после точки решил проверить,
        // а есть ли какие-либо варианты как это записать и нашел "Arrays.stream(v).sum()".
        // Но думаю это не соответсвуем поставленному условию задания и
        // накалякал второй вариант тела через цикл.
        //return sum;
        return Arrays.stream(v).sum();
    }

    public static double minusAll(double source, double... v) {
        for (double oneFromV : v) {
            source -= oneFromV;
        }
        //return source - Arrays.stream(v).sum(); // тут так же два варианта тела метода
        return source;
    }

    public static double multAll(double... v) {
        double result = 1;
        for (double oneFromV : v) {
            result *= oneFromV;
        }
        return result;
    }

    private static double pow(double value, int powValue) { //метод имеет м.д privat потому-что будет вызван лишь в методе powAll
        if (powValue == 0) {
            return 1; //любое числов 0 степени равно 0
        }
        double result = 1;
        //т.к мы пишем аналог классу Math у нас недоступен метод Math.abs. Запишем его аналог
        int absExponent = powValue > 0 ? powValue : -powValue;

        for (int i = 0; i < absExponent; i++) {
            result *= value;
        }
        return powValue > 0 ? result : 1 / result; //этим отсекаем возможность ввода отрицательной степени,
        // для расчета которой требуется записать сложный код, раздумья над которым сломают мне голову))
    }

    public static double powAll(double source, double... v) {
        double result = source;
        for (double oneFromV : v) {
            result = pow(result, (int) oneFromV); //приводим тип числа вводимой степени к int чтобы
            // не ломать голову над записью решения дробных степеней
        }
        return result;
    }
}
//No1
//Создайте утилитарный класс, который будет аналогом класса Math.
// В нём будет один приватный конструктор, а также только статические методы:
//• addAll - сложение неограниченного числа аргументов
//• minusAll – принимает исходное число и неограниченный набор аргументов, которые
//нужно вычесть из исходного числа
//• multAll – перемножает все данные аргументы
//• powAll – принимает исходное число-основание и неограниченный
// набор аргументов степеней. Нужно последовательно возвести основание во все степени.
//Используйте все методы в коде метода main.
