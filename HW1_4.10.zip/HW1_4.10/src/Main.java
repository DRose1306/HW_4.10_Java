import util.MathUtils;

public class Main {
    public static void main(String[] args) {
        System.out.println("Результат сложения равен: ");
        System.out.println(MathUtils.addAll(1.5, 2, 6));
        System.out.println("Результат вычитания равен: ");
        System.out.println(MathUtils.minusAll(100, 49, 23.5, 10.5));
        System.out.println("Результат умножения равен: ");
        System.out.println(MathUtils.multAll(2,3,5));
        System.out.println("Результат возведения в степень равен: ");
        System.out.println(MathUtils.powAll(2,2,2));
    }
}
//No1
//Создайте утилитарный класс, который будет аналогом класса Math.
// В нём будет один приватный конструктор, а также только статические методы:
//• addAll - сложение неограниченного числа аргументов
//• minusAll – принимает исходное число и неограниченный набор аргументов, которые
//нужно вычесть из исходного числа
//• multAll – перемножает все данные аргументы
//• powAll – принимает исходное число-основание и неограниченный
// набор аргументов степеней. Нужно последовательно возвести основание во все степени.
//Используйте все методы в коде метода main.