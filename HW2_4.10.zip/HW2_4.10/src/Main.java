import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Auto honda = new Auto("Honda", "Седан", 1.4, "гибрид", 265);
        System.out.println(honda);

        Auto mercedes = new Auto("Мерседес", "Универсал", 2.0, "бензин", 250);
        System.out.println(mercedes);

        Auto audi = new Auto("АУДИ", "Внедорожник", 3.2, "дизель", 240);
        System.out.println(audi);
        System.out.println();

        Auto[] auto = {honda, mercedes, audi};
        Arrays.toString(auto);
        System.out.println(Arrays.toString(auto));

        //Реализация метода toString
        //public static String toString(Object[] a) {
        //        if (a == null)
        //            return "null";
        //
        //        int iMax = a.length - 1;
        //        if (iMax == -1)
        //            return "[]";
        //
        //        StringBuilder b = new StringBuilder();
        //        b.append('[');
        //        for (int i = 0; ; i++) {
        //            b.append(String.valueOf(a[i]));
        //            if (i == iMax)
        //                return b.append(']').toString();
        //            b.append(", ");
        //        }
        //    }
    }
}
//No2
//Напишите класс Автомобиль с минимум пятью полями.
// Переопределите метод toString, чтобы он выводил полное описание автомобиля по его полям.
// В программе создайте 3 разных автомобиля и выведите каждый из них в консоль.
//Создайте массив из этих автомобилей. С помощью Arrays.toString() превратите массив в строку и выведите в консоль.
//Перейдите в код метода Arrays.toString() и посмотрите на его реализацию.
// В какой момент автомобиль становится строкой внутри этого метода?