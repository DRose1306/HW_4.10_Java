public class Auto {
    public String mark;
    public String bodyType;
    public double engineCapacity;
    public String engineType;
    public  int maxSpeed;

    @Override
    public String toString() {
        return "Auto{" +
                "mark= '" + mark + '\'' +
                ", bodyType= '" + bodyType + '\'' +
                ", engineCapacity= " + engineCapacity +
                ", engineType= '" + engineType + '\'' +
                ", maxSpeed= " + maxSpeed +
                '}';
    }

    public Auto(String mark, String bodyType, double engineCapacity, String engineType, int maxSpeed) {
        this.mark = mark;
        this.bodyType = bodyType;
        this.engineCapacity = engineCapacity;
        this.engineType = engineType;
        this.maxSpeed = maxSpeed;
    }
}
//No2
//Напишите класс Автомобиль с минимум пятью полями.
// Переопределите метод toString, чтобы он выводил полное описание автомобиля по его полям.
// В программе создайте 3 разных автомобиля и выведите каждый из них в консоль.
//Создайте массив из этих автомобилей. С помощью Arrays.toString() превратите массив в строку и выведите в консоль.
//Перейдите в код метода Arrays.toString() и посмотрите на его реализацию.
// В какой момент автомобиль становится строкой внутри этого метода?
